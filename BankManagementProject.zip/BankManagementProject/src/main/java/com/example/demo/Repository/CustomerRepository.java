package com.example.demo.Repository;


import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.Entity.Customer;


@Repository
public interface CustomerRepository extends JpaRepository<Customer, Integer> {

	@Transactional
	@Modifying(clearAutomatically = true)
	@Query("update Customer set custName = :custName where acctID = :acctID")
	void saveCustomerNameByAcctID(@Param(value = "acctID") int acctID, @Param(value = "custName") String custName);

	@Transactional
	@Modifying(clearAutomatically = true)
	@Query("update Customer set city = :city where acctID = :acctID")
	void saveCustomerCityByAcctID(@Param(value = "acctID") int acctID, @Param(value = "city") String city);
	
	@Transactional
	@Modifying(clearAutomatically = true)
	@Query("update Customer set state = :state where acctID = :acctID")
	void saveCustomerStateByAcctID(@Param(value = "acctID") int acctID, @Param(value = "state") String state);
	
	@Transactional
	@Modifying(clearAutomatically = true)
	@Query("update Customer set country = :country where acctID = :acctID")
	void saveCustomerCountryByAcctID(@Param(value = "acctID") int acctID, @Param(value = "country") String country);
	
	@Transactional
	@Modifying(clearAutomatically = true)
	@Query("update Customer set password = :password where acctID = :acctID")
	void saveCustomerPasswordByAcctID(@Param(value = "acctID") int acctID, @Param(value = "password") String password);
	
	@Transactional
	@Modifying(clearAutomatically = true)
	@Query("update Customer set phoneNo = :phoneNo where acctID = :acctID")
	void saveCustomerPhoneNoByAcctID(@Param(value = "acctID") int acctID, @Param(value = "phoneNo") String phoneNo);

}
