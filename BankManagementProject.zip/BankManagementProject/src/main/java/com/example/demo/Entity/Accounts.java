package com.example.demo.Entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Accounts {

//	@GeneratedValue(strategy = GenerationType.AUTO)
	@Id
	private int acctID;
	private int balance;
	private String acctStatus;
	
	public Accounts(int acctID, int balance, String acctStatus) {
		super();
		this.acctID = acctID;
		this.balance = balance;
		this.acctStatus = acctStatus;
	}

	public Accounts() {
		super();
	}

	public int getAcctID() {
		return acctID;
	}

	public void setAcctID(int acctID) {
		this.acctID = acctID;
	}

	public int getBalance() {
		return balance;
	}

	public void setBalance(int string) {
		this.balance = string;
	}

	public String getAcctStatus() {
		return acctStatus;
	}

	public void setAcctStatus(String acctStatus) {
		this.acctStatus = acctStatus;
	}

	@Override
	public String toString() {
		return "Accounts [acctID=" + acctID + ", balance=" + balance + ", acctStatus=" + acctStatus + "]";
	}
	
	
}
