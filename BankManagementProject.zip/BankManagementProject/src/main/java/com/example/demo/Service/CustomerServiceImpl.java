package com.example.demo.Service;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.example.demo.Entity.Customer;
import com.example.demo.Error.CustomerNotFoundException;
import com.example.demo.Repository.CustomerRepository;




@Service
public class CustomerServiceImpl implements CustomerService{
	
	@Autowired
	private CustomerRepository customerRepository;

	@Override
	public Customer createCustomer(Customer customer) {
		return customerRepository.save(customer);
		
	}

	@Override
	public Customer getCustomerInfo(int acctID) throws CustomerNotFoundException{
		Optional<Customer> customer =customerRepository.findById(acctID);
		if(!customer.isPresent()) {
			throw new CustomerNotFoundException("Customer Not Available");
		}
		else {
		  return customerRepository.findById(acctID).orElse(null);
		}
	}

	@Override
	public void deleteCustomer(int acctID) throws CustomerNotFoundException{
		Optional<Customer> customer =customerRepository.findById(acctID);
		if(!customer.isPresent()) {
			throw new CustomerNotFoundException("Customer Not Available");
		}
		else {
			customerRepository.deleteById(acctID);
		}
	}

	@Override
	public List<Customer> fetchCustomerList() {
		return customerRepository.findAll();
	}

	@Override
	public void updateCustomerName(int acctID, String custName) throws CustomerNotFoundException{

		customerRepository.saveCustomerNameByAcctID(acctID, custName);
	}

	@Override
	public void updateCustomerCity(int acctID, String city) {
		customerRepository.saveCustomerCityByAcctID(acctID, city);
	}

	@Override
	public void changeCustomerState(int acctID, String state) {
		customerRepository.saveCustomerStateByAcctID(acctID, state);
		
	}

	@Override
	public void changeCustomerCountry(int acctID, String country) {
		customerRepository.saveCustomerCountryByAcctID(acctID, country);
		
	}

	@Override
	public void changeCustomerPassword(int acctID, String password) {
		customerRepository.saveCustomerPasswordByAcctID(acctID, password);
	}

	@Override
	public void changeCustomerPhoneNo(int acctID, String phoneNo) {
		customerRepository.saveCustomerPhoneNoByAcctID(acctID, phoneNo);
	}

}
