package com.example.demo.Service;

import java.util.List;
import com.example.demo.Entity.Accounts;
import com.example.demo.Error.AccountNotFoundException;

public interface AccountService {

	void createAccount(Accounts acct);

	int getBalance(int acctID) throws AccountNotFoundException;

	void withdrawAmount(int acctID, int amount) throws AccountNotFoundException;

	void transferAmount(int acctID, int destAcctID, int amount) throws AccountNotFoundException;

	void deleteAccount(int acctID) throws AccountNotFoundException;

	Accounts getAccountInfo(int acctID) throws AccountNotFoundException;

	List<Accounts> fetchAccountList();

	void depositAmount(int acctID, int amount) throws AccountNotFoundException;


}
