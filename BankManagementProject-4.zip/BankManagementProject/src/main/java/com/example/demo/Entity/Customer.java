package com.example.demo.Entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;

import org.hibernate.validator.constraints.Length;

@Table(name = "Customer_Table")
@Entity
public class Customer {	
	@Id
	private int acctID;
	@NotBlank(message = "Customer Name Should not be Blank")
	private String custName;
	@NotBlank(message= "City Name Should not be Blank")
	private String city;
	@NotBlank(message= "State Name Should not be Blank")
	private String state;
	@NotBlank(message= "Country Name Should not be Blank")
	private String country;
	@Length(min=10, max=13, message= "mobile Number must be 10 Digits")
	private String phoneNo;
	@NotBlank(message= "Password Should not be Blank")
	private String password;	
	
	public Customer() {
		super();
		
	}
	public Customer(int acctID, @NotBlank(message = "please add customer name") String custName, String city, String state, String country, String phoneNo,
			String password) {
		super();
		this.acctID = acctID;
		this.custName = custName;
		this.city = city;
		this.state = state;
		this.country = country;
		this.phoneNo = phoneNo;
		this.password = password;
	}
	public int getAcctID() {
		return acctID;
	}
	public void setAcctID(int acctID) {
		this.acctID = acctID;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Override
	public String toString() {
		return "Customer [acctID=" + acctID + ", custName=" + custName + ", city=" + city + ", state=" + state
				+ ", country=" + country + ", phoneNo=" + phoneNo + ", password=" + password + "]";
	}
}
